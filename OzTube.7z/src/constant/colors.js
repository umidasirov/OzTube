export const colors ={
    primary:"#181818",
    secondary:'#333333',
    white:"#ffff"
}